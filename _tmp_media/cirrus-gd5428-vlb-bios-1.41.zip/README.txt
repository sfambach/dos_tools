ECS / Elitegroup VI-711A Rev 1.0 - Cirrus Logic CL-GD5428 VLB
BIOS: CL-GD542X VGA BIOS Version 1.41, (c) 1992-1993 Cirrus Logic, (c) 1987-1990 Quadtel
EPROM: ST M27C512-15XF1 (64 KB), label "(c) 1994 Cirrus Logic / (c) 1994 Quadtel"

CirrusLogic_GD5428_VLB_chipdump.rom  65536 bytes  raw EPROM dump
  - 32 KB content mirrored twice (A15 unused)
  - first 16 KB = even bytes, second 16 KB = odd bytes of the BIOS (card wiring)
CirrusLogic_GD5428_VLB_BIOS_1.41.bin  32768 bytes  linear option ROM image (55 AA 40, checksum 00)
  - use this one for emulators (86Box, PCem) or EPROM burning on a linear card
3bcb65b35384e6408ae37a9a8aea85b9 CirrusLogic_GD5428_VLB_BIOS_1.41.bin
53dbd4cbd56acc46f7ef0ce2c94bbab7 CirrusLogic_GD5428_VLB_chipdump.rom
